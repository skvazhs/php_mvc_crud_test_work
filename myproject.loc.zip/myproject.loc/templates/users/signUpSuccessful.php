<?php include __DIR__ . '/../header.php'; ?>
<div style="text-align: center;">
    <h1>Регистрация прошла успешно!</h1>
    Ссылка для активации вашей учетной записи отправлена вам на email.
</div>
<?php include __DIR__ . '/../footer.php'; ?>
