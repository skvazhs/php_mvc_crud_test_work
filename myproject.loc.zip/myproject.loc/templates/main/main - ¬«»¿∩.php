<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Test API CRUD</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
   
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-md-12 mt-5">
            <h1 class="text-center">
                PHP MVC CRUD TEST WORK
            </h1>

            <hr style="height: 1px; color: black; background-color:black;">

        </div>
    </div>
</div>


<div class="container">
    <div class="row">
        <div class="col-md-12 mt-5">
            
            Таблица продукты

            <hr style="height: 1px; color: black; background-color:black;">

        </div>
    </div>
</div>

<div class="container">
    <div id="result">

    </div>
</div>

<div class="container-fluid" id="table-header">

    <div class="row" id="record" name="record">

        <div class="col-md-auto"  name="provider_field_" id="provider_field_">
            <input type="text" value="Название" disabled>
            <!-- Название -->
        </div>

        <div class="col-md-auto"  name="provider_field_" id="provider_field_">
            <input type="text" value="Поставшик" disabled>
            <!-- Поставшик -->
        </div>
        
        <div class="col-md-auto"  name="count_field_" id="count_field_">
            <input type="text" value="Количество" disabled>
            <!-- Количество -->
        </div>
        
        <div class="col-md-auto"  name="action_edit_" id="action_edit_">
            Действия
        </div>
    </div>
    
</div>
<div class="container-fluid" name="box_content" id="box_content">
    

    <div class="row" id="record" name="record">

        <div class="col-md-auto"  name="provider_field_" id="provider_field_">
            <input type="text" name="name_1" id="name_1">
        </div>

        <div class="col-md-auto"  name="provider_field_" id="provider_field_">
            <input type="text" name="provider_1" id="provider_1">
        </div>
        
        <div class="col-md-auto"  name="count_field_" id="count_field_">
            <input type="text" name="count_1" id="count_1">
        </div>
        
        <div class="col-md-auto"  name="action_edit_" id="action_edit_">
            <button type="submit" class="btn btn-success" name="action_edit_1" id="action_edit_1">
                Редактировать
            </button>
        </div>
        
        <div class="col-md-auto"  name="action_delete_" id="action_delete_">
            <button type="submit" class="btn btn-danger" name="action_delete_1" id="action_delete_1">
                Удалить
            </button>

        </div>
    </div>
    
</div> 


<button type="button" class="btn btn-primary" id="openCreateModal">
    Создать
</button>

<div id="alert-box"></div>
<hr>


<!-- Modal -->
<!-- Модальное окно создания записи -->
<div class="modal fade" id="createModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Создание новой записи</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" class="closeBtn"></button>
        <!-- <button type="button" class="btn-close" aria-label="Close" class="closeBtn"></button> -->
      </div>
      <form action="" method="post">
      <div class="modal-body">


            <div class="row" id="record" name="record">
                <!-- <div id="result"></div> -->
                <div class="col-md-auto"  name="provider_field_" id="provider_field_">
                    <input type="text" name="name" id="name" value="test" required placeholder="Название продукта">
                </div>
                
                <div class="col-md-auto"  name="provider_field_" id="provider_field_">
                    <input type="text" name="provider" id="provider" value="test" required placeholder="Поставщик">
                </div>
                <!-- name -->
                <div class="col-md-auto"  name="count_field_" id="count_field_">
                    <input type="text" ="count" id="count"  min="0" value="1" required placeholder="Количество продукта">
                </div>
                <div id="modal_result"></div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="closeBtn" class="closeBtnModal">Закрыть</button>
            <!-- <button type="button" class="btn btn-primary" id="createBtn">Создать</button> -->
            <button type="button" class="btn btn-primary" id="testBtn">Создать</button>
        </div>
    </form>
    </div>
  </div>
</div>

<!-- Modal -->
<!-- Модальное окно для изменения записи -->
<div class="modal fade" id="updateModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Изменение записи таблицы</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" class="closeBtnUpdate"></button>
      </div>
      <div class="modal-body" id="updateModalBody">

            <div class="row" id="record" name="record">
                <!-- <div id="result"></div> -->
                <input type="hidden" name="edit_id" id="edit_id" value="test" required>
                <div class="col-md-auto"  name="edit_provider_field_" id="edit_provider_field_">
                    <input type="text" name="edit_name" id="edit_name" value="test" required>
                </div>

                <div class="col-md-auto"  name="edit_provider_field_" id="edit_provider_field_">
                    <input type="text" name="edit_provider" id="edit_provider" value="test" required>
                </div>
                
                <div class="col-md-auto"  name="edit_count_field_" id="edit_count_field_">
                    <input type="text" name="edit_count" id="edit_count"  min="0" value="1" required>
                </div>

            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="closeBtn"  class="closeBtnModal">Закрыть</button>
        <button type="button" class="btn btn-primary" id="updateModalBtn">Изменить</button>
      </div>
    </div>
  </div>
</div>


<!-- Modal -->
<!-- Модальное окно для удаления записи -->
<div class="modal fade" id="deleteModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Удаление записи таблицы</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" class="closeBtnUpdate"></button>
      </div>
      <div class="modal-body" id="deleteModalBody">
            Вы действительно хотите удалить запись в таблице?
            <div class="row" id="record" name="record">
                
                <input type="hidden" id="delete_id" name="delete_id" value="">
                <div class="col-md-auto"  name="delete_name_field" id="delete_name_field">
                    <input type="text" name="delete_name" id="delete_name" value="test" disabled required>
                </div>

                <div class="col-md-auto"  name="delete_provider_field" id="delete_provider_field">
                    <input type="text" name="delete_provider" id="delete_provider" value="test" disabled required>
                </div>
                
                <div class="col-md-auto"  name="delete_count_field" id="delete_count_field">
                    <input type="text" name="delete_count" id="delete_count"  min="0" value="1" disabled required>
                </div>

            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="closeBtn"  class="closeBtnModal">Закрыть</button>
        <button type="button" class="btn btn-primary" id="deleteModalBtn">Удалить</button>
      </div>
    </div>
  </div>
</div>





    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    <script src="js/my_jq.js"></script>
</body>
</html>