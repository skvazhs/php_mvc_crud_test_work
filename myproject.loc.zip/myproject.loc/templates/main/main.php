<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.3/font/bootstrap-icons.css">


    <title>PHP MVC CRUD TEST WORK</title>
	
	 <style>
	 .btn-label {
	position: relative;
	left: -12px;
	display: inline-block;
	padding: 6px 12px;
	background: rgba(0, 0, 0, 0.15);
	border-radius: 3px 0 0 3px;
}

.btn-labeled {
	padding-top: 0;
	padding-bottom: 0;
}

.btn {
	margin-bottom: 10px;
}
	 </style>
  </head>
  <body>

<div class="container">
    <div class="row">
        <div class="col-md-12 mt-2">
            <h1 class="text-center">
                PHP MVC CRUD TEST WORK
            </h1>
            <hr style="height: 1px; color: black; background-color:black;">

        </div>
    </div>
</div>


<div class="container">
    <div class="row">
        <div class="col-md-12 mt-2">
			<h2 class="text-center">
				Таблица продукты
            </h2>
            <hr style="height: 1px; color: black; background-color:black;">

        </div>
    </div>
 <!--/div-->

	<div  class="d-flex justify-content-end">
		<!--button type="button" class="btn btn-primary" id="openCreateModal">
			Создать
		</button-->
		<button type="button" class="btn btn-primary m-1" data-bs-toggle="modal" data-bs-target="#createModal">
			+1
		</button>
		
		<button type="button" class="btn btn-secondary m-1" id="fetchAllBtn">
			<i class="bi bi-arrow-clockwise"></i>
		</button>
	</div>

<hr style="height: 1px; color: black; background-color:black;">

<div class="container">
    <div id="result">

    </div>
</div>

<div class="container-fluid" id="table-header">

    <div class="row" id="record" name="record">

        <div class="col-md-auto" name="provider_field_" id="provider_field_">
            <input type="text" value="Название" disabled="">
            <!-- Название -->
        </div>

        <div class="col-md-auto" name="provider_field_" id="provider_field_">
            <input type="text" value="Поставшик" disabled="">
            <!-- Поставшик -->
        </div>
        
        <div class="col-md-auto" name="count_field_" id="count_field_">
            <input type="text" value="Количество" disabled="">
            <!-- Количество -->
        </div>
        
        <div class="col-md-auto" name="action_edit_" id="action_edit_">
            Действия
        </div>
        

        
    </div>
    
</div>


	<!--div class="container-fluid d-flex justify-content-xxl-center flex-column" name="box_content" id="box_content"-->
	<div class="container-fluid"  name="box_content" id="box_content">
		<!--div id="record_1" name="record_1" class="row mt-1">

			<div id="name_box_1" name="name_box_1" class="col-md-auto">
				<input type="text" id="name_1" name="name_1" value="Продукт 1">
			</div>

			<div id="provider_box_1" name="provider_box_1" class="col-md-auto">
				<input type="text" id="provider_1" name="provider_1" value="Поставщик 1">
			</div>

			<div id="count_box_1" name="count_box_1" class="col-md-auto">
				<input type="text" id="count_1" name="count_1" value="1">
			</div>

			<div id="action_edit_box_1" name="action_edit_box_1" class="col-md-auto">
				<button type="submit" id="action_delete_1" name="action_delete_1" class="btn btn-success">
				<span class="fa fa-edit"></span>
				<i class="bi bi-pencil-square"></i>
				</button>
				<button type="submit" id="action_delete_1" name="action_delete_1" class="btn btn-danger">
				<i class="bi bi-trash3"></i></button>
			</div>

			<div id="action_delete_box_1" name="action_delete_box_1" class="col-md-auto">
			</div>
			
		</div-->
	</div>
</div>
			<!--button type="button" class="btn btn-labeled btn-danger">
				<span class="btn-label">
					<i class="bi bi-trash3"></i>
				</span>
			</button-->


	<!-- Button trigger modal -->
<!-- <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createModal"> -->
  <!-- Создание -->
<!-- </button> -->

<!-- Modal -->
<div class="modal fade" id="createModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Создание записи</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="createModalBody">
			<div class="row" id="record" name="record">
				<!-- <div id="result"></div> -->
				<div class="col-md-auto"  name="provider_field_" id="provider_field_">
					<input type="text" name="name" id="name" value="test" required placeholder="Название продукта">
				</div>
				
				<div class="col-md-auto"  name="provider_field_" id="provider_field_">
					<input type="text" name="provider" id="provider" value="test" required placeholder="Поставщик">
				</div>
				<!-- name -->
				<div class="col-md-auto"  name="count_field_" id="count_field_">
					<input type="text" ="count" id="count"  min="0" value="1" required placeholder="Количество продукта">
				</div>
				<div id="modal_result"></div>
			</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="createModalBtn">Создать</button>
      </div>
    </div>
  </div>
</div>
	
	<!-- Button trigger modal -->
<!-- <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#updateModal"> -->
  <!-- Редактирование -->
<!-- </button> -->

<!-- Modal -->
<div class="modal fade" id="updateModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Редактирование записи</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="updateModalBody">
            <div class="row" id="record" name="record">
                <!-- <div id="result"></div> -->
                <input type="hidden" name="edit_id" id="edit_id" value="test" required>
                <div class="col-md-auto"  name="edit_provider_field_" id="edit_provider_field_">
                    <input type="text" name="edit_name" id="edit_name" value="test" required>
                </div>

                <div class="col-md-auto"  name="edit_provider_field_" id="edit_provider_field_">
                    <input type="text" name="edit_provider" id="edit_provider" value="test" required>
                </div>
                
                <div class="col-md-auto"  name="edit_count_field_" id="edit_count_field_">
                    <input type="text" name="edit_count" id="edit_count"  min="0" value="1" required>
                </div>
				
				<!-- Для ошибок редактирования -->
				<div id="result-update-modal">
				</div>

            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="updateModalBtn">Изменить</button>
      </div>
    </div>
  </div>
</div>
	
	<!-- Button trigger modal -->
<!-- <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#deleteModal"> -->
  <!-- Удаление -->
<!-- </button> -->

<!-- Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Удаление записи</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="deleteModalBody">
		<div class="container-fluid" id="table-header">

			<div class="row" id="record" name="record">

				<input type="hidden" value="" name="delete_id" id="delete_id" disabled="">
				<div class="col-md-auto" name="provider_field_" id="provider_field_">
					<input type="text" value="Название" name="delete_name" id="delete_name" disabled="">
					<!-- Название -->
				</div>

				<div class="col-md-auto" name="provider_field_" id="provider_field_">
					<input type="text" value="Поставшик" name="delete_provider" id="delete_provider" disabled="">
					<!-- Поставшик -->
				</div>
				
				<div class="col-md-auto" name="count_field_" id="count_field_">
					<input type="text" value="Количество" name="delete_count" id="delete_count" disabled="">
					<!-- Количество -->
				</div>
				
				<div id="result-delete-modal">
				</div>
			</div>
			
		</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-danger" id="deleteModalBtn">Удалить</button>
      </div>
    </div>
  </div>
</div>

<!-- мысль - это посредник между духом, телом и материальным -->
	

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
	<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
	
    <script src="js/my_script.js"></script>
	
	
  </body>
</html>