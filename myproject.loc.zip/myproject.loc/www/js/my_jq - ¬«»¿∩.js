
$(".alert").on ('click', function(e){
    alert($(this));
 $(this).hide();
})

function fetch() {

    $.ajax({
        url: "/api/products/fetchall",
        type: "POST",
        success: function(data) {

            console.log(typeof(data));
            console.log(data);


            var box_content = document.querySelector("#box_content");
            box_content.innerHTML = "";
            var box_content1 = $("#box_content");

            for (let ob of data) {

                // $("#box_content").append("<div>qwerty</div>"); 
                $("#box_content").append('<div id="record_' + ob["id"] + '" namne="record_' + ob["id"] + '" class="row mt-1"></div>');
                // $('#record_'+ob["id"]).append('<div id="name_box_'+ob["id"]+'" namne="name_box_'+ob["id"]+'"><input type="text" id="name_'+ob["id"]+'" name="name_'+ob["id"]+'" value="'+ob["name"]+'"></div>');

                $('#record_' + ob["id"]).append('<div id="name_box_' + ob["id"] + '" namne="name_box_' + ob["id"] + '" class="col-md-auto"></div>');
                $('#record_' + ob["id"]).append('<div id="provider_box_' + ob["id"] + '" namne="provider_box_' + ob["id"] + '" class="col-md-auto"></div>');
                $('#record_' + ob["id"]).append('<div id="count_box_' + ob["id"] + '" namne="count_box_' + ob["id"] + '" class="col-md-auto"></div>');

                $('#record_' + ob["id"]).append('<div id="action_edit_box_' + ob["id"] + '" namne="action_edit_box_' + ob["id"] + '" class="col-md-auto"></div>');
                $('#record_' + ob["id"]).append('<div id="action_delete_box_' + ob["id"] + '" namne="action_delete_box_' + ob["id"] + '" class="col-md-auto"></div>');


                $('#name_box_' + ob["id"]).append('<input type="text" id="name_' + ob["id"] + '" name="name_' + ob["id"] + '" value="' + ob["name"] + '">');
                $('#provider_box_' + ob["id"]).append('<input type="text" id="provider_' + ob["id"] + '" name="provider_' + ob["id"] + '" value="' + ob["provider"] + '">');
                $('#count_box_' + ob["id"]).append('<input type="text" id="count_' + ob["id"] + '" name="count_' + ob["id"] + '" value="' + ob["count"] + '">');

                // $('#record_'+ob["id"]).append('<div id="provider_box_'+ob["id"]+'" namne="provider_box_'+ob["id"]+'" class="col-md-auto"><input type="text" id="provider_'+ob["id"]+'"  name="provider_'+ob["id"]+'" value="'+ob["provider"]+'"></div>');
                // $('#record_'+ob["id"]).append('<div id="count_box_'+ob["id"]+'" namne="count_box_'+ob["id"]+'" class="col-md-auto"><input type="text" id="count_'+ob["id"]+'"  name="count_'+ob["id"]+'" value="'+ob["count"]+'"></div>');
                // $('#record_'+ob["id"]).append('<div id="action_edit_box_'+ob["id"]+'" namne="action_edit_box_'+ob["id"]+'" class="col-md-auto"><button type="submit">Редактировать<button></div>');

                $('#action_edit_box_' + ob["id"]).append('<button type="submit" id="action_delete_' + ob["id"] + '" name="action_delete_' + ob["id"] + '" class="btn btn-success">Редактировать</button></div>');
                $('#action_delete_box_' + ob["id"]).append('<button type="submit" id="action_delete_' + ob["id"] + '" name="action_delete_' + ob["id"] + '" class="btn btn-danger">Удалить</button>');

            }

        }
    });
}


function create_product() {

    // Чтение значений полей из модального окна создания записи
    var products = [{

        "name": $("#name").val(),
        "provider": $("#provider").val(),
        "count": $("#count").val()
    }];

    console.log(products);

    var jqxhr = $.ajax({

        url: '/api/products/create',
        type: 'POST',
        data: JSON.stringify({ products }),
        dataType: "JSON",

        success: function(data) {
            if (!data["status"]) {

                $("#result_create").className = "alert alert-danger";
                var msg = '<div class="alert alert-danger"><i class="bi bi-x">' + (data["msgs"].join("<br>")) + '</div>';
                result = '<div class="alert alert-danger"><i class="bi bi-x">' + (data["msgs"].join("<br>")) + '</div>';
                $("#result_create").innerHTML = $msg;
                console.log(result);
                myModal.hide();
            }
            if (data["status"]) {

                $("#create_btn").hide(); // = "alert alert-success";
                $("#result_create").className = "alert alert-success";
                $("#result_create").innerHTML = "Запись успешно создана";

                var msg = '<div class="alert alert-success"><i class="bi bi-x">' + (data["msgs"].join("<br>")) + '</div>';
                result = '<div class="alert alert-success"><i class="bi bi-x">' + (data["msgs"].join("<br>")) + '</div>';
                $("#result_create").innerHTML = msg;
                $("#result").html(msg);
                console.log(msg);
                console.log(result);

                const myModal = new bootstrap.Modal('#createModal')
                myModal.hide();

                $('#result').html(result);
                fetch();
            }
        },

        error: function(jqxhr, status, data) {

            alert("Ошибка");
            // console.log(jqxhr, status, data);
            console.log(data);
            console.log(jqxhr.responseText);
            var data = $.parseJSON(jqxhr.responseText);
            if (!data["status"]) {

                var msg = '<div class="alert alert-danger"><i class="bi bi-x">' + (data["msgs"].join("<br>")) + '</div>';
                result = '<div class="alert alert-danger"><i class="bi bi-x">' + (data["msgs"].join("<br>")) + '</div>';
                $("#result").html(msg);
                console.log(result);
                myModal.hide();
            }
        },
        statusCode: {
            404: function(jqxhr, status, error) {

                $("#result_create").className = "alert alert-danger";
                var msg = '<div class="alert alert-danger"><i class="bi bi-x">' + (data["msgs"].join("<br>")) + '</div>';
                result = '<div class="alert alert-danger"><i class="bi bi-x">' + (data["msgs"].join("<br>")) + '</div>';
                $("#result").html(msg);
                console.log(jqxhr.responseText);
                myModal.hide();

            }
        }
    })
}


$(document).ready(function() {

    // Получение всех записей таблицы из БД - запрос на сервер получиь всё
    fetch();

    // Определение модального окна создания записи
    const myModal = new bootstrap.Modal('#createModal')

    // Для редактирвоания записи определяю мод окно
    const myUpdateModal = new bootstrap.Modal('#updateModal')

    // Для удаления модальное окно
    const myDeleteModal = new bootstrap.Modal('#deleteModal')

    // кнопочки
    const openCreateModal = document.getElementById('openCreateModal');
    const createBtn = document.getElementById('createBtn');
    const testBtn = document.getElementById('testBtn');
    const deleteModalBtn = document.getElementById('deleteModalBtn');

    const closeButton = document.getElementById('closeBtn');


    // Теперь слушатели событий при закрытии любого из модального окна:
    // Надо получить свежий список всех записей в таблице
    // не будет работать при нажатии на иконку закрытия крестик


    $("#myModal").on("hide.bs.modal", function(e) {
        $('#name').val = "";
        $('#provider').val = "";
        $('#count').val = "";
        $('#modal_result').html("  ");
        fetch();
    })

    $("#myModal").on("hidden.bs.modal", function(e) {
        $('#name').val = "";
        $('#provider').val = "";
        $('#count').val = "";
        $('#modal_result').html("  ");
        fetch();
    })

    $("#myUpdateModal").on("hide.bs.modal", function(e) {
        fetch();
    })

    $("#myDeleteModal").on("hide.bs.modal", function(e) {
        fetch();
    })

    testBtn.addEventListener("click", () => {
        
        
        var products = [{

            "name": $("#name").val(),
            "provider": $("#provider").val(),
            "count": $("#count").val()
        }];

        console.log(products);

        if (($("#name").val() == "") || ($("#provider").val() == "") || ($("#count").val() == "")) {

            var msg = '<div class="alert alert-warning">Ошибка ввода</div>';
            $('#modal_result').html(msg);
            // exit(0);
        } else {
            
            create_product();
            myModal.hide()
        }
        
    })
 
    closeButton.addEventListener("click", () => {
        $('#modal_result').html("");
        myModal.hide()
    })

    openCreateModal.addEventListener("click", () => {
        myModal.show()
    })

    $("#result").on('click', function(e) {
        $(this).html("");
        $('#modal_result').html("");
        $('#modal_result').hide();
    })

    $(".alert").on('click', function(e) {
        $(this).hide();
    }) 

    // deleteModalBtn.addEventListener("click",()=>{
    //     myDeleteModal.hide();
    // })

})

    // $("#deleteModalBtn").on('click', function(e){
    //     const myDeleteModal = new bootstrap.Modal(document.getElementById('deleteModal'))
    //     myDeleteModal.hide();
    //     // myDeleteModal.toggle();

    // })





$('#box_content')

.on('click', '.btn-danger', function(e) {

    // $(this).closest('.row').remove()

    var parent_id = this.parentNode; //.id;
    var el_id = e.target.id;
    var record_id = el_id.split("_")[2];
    console.log(parent_id);
    console.log(e.target.id);
    console.log(record_id);

    const row = $(this).closest('.row')

    console.log('name', row.find('input[name="name_' + record_id + '"]').val())
    console.log('provider', row.find('input[name="provider_' + record_id + '"]').val())
    console.log('count', row.find('input[name="count_' + record_id + '"]').val())

    console.log($('#deleteModal').find('#delete_id').val(record_id));
    console.log($('#deleteModal').find('#delete_name').val($("#name_" + record_id).val()));
    console.log($('#deleteModal').find('#delete_provider').val($("#provider_" + record_id).val()));
    console.log($('#deleteModal').find('#delete_count').val($("#count_" + record_id).val()));

    const myDeleteModal = new bootstrap.Modal('#deleteModal')

    myDeleteModal.show();

})

.on('click', '.btn-success', function(e) {

    var parent_id = this.parentNode; //.id;
    var el_id = e.target.id;
    var record_id = el_id.split("_")[2];
    
    console.log(parent_id);
    console.log(parent_id.parentNode.id);
    console.log(e.target.id);
    console.log(record_id);

    const row = $(this).closest('.row')

    console.log('name', row.find('input[name="name_' + record_id + '"]').val())
    console.log('provider', row.find('input[name="provider_' + record_id + '"]').val())
    console.log('count', row.find('input[name="count_' + record_id + '"]').val())

    console.log($('#updateModal').find('#edit_id').val(record_id));
    console.log($('#updateModal').find('#edit_name').val($("#name_" + record_id).val()));
    console.log($('#updateModal').find('#edit_provider').val($("#provider_" + record_id).val()));
    console.log($('#updateModal').find('#edit_count').val($("#count_" + record_id).val()));

    // Отображение модального окна удаления
    const updateModal = new bootstrap.Modal('#updateModal')
    updateModal.show();
})


// Сам запрос на удаление записи - работа с сервером
function deleteRecord(products) {

    console.log(products);

    var jqxhr = $.ajax({

        url: '/api/products/delete',
        type: 'DELETE',
        data: JSON.stringify({ products }),
        dataType: "JSON",

        success: function(data) {

            if (!data["status"]) {

                var msg = '<div class="alert alert-danger"><i class="bi bi-x">' + (data["msgs"].join("<br>")) + '</div>';
                result = '<div class="alert alert-danger"><i class="bi bi-x">' + (data["msgs"].join("<br>")) + '</div>';
                
                            const myModal = new bootstrap.Modal('#deleteModal');
                            myModal.hide();
            }

            if (data["status"]) {

                var msg = '<div class="alert alert-success"><i class="bi bi-x">' + (data["msgs"].join("<br>")) + '</div>';
                result = '<div class="alert alert-success"><i class="bi bi-x">' + (data["msgs"].join("<br>")) + '</div>';
                const myModal = new bootstrap.Modal('#deleteModal');
                myModal.hide();
            }

            $("#result").html(msg);
            console.log(msg);
            console.log(result);
            $('#result').html(result);
            fetch();
        },

        error: function(jqxhr, status, data) {

            console.log(data);
            console.log(jqxhr.responseText);
            var data = $.parseJSON(jqxhr.responseText);

            if (!data["status"]) {

                var msg = '<div class="alert alert-danger"><i class="bi bi-x">' + (data["msgs"].join("<br>")) + '</div>';
                result = '<div class="alert alert-danger"><i class="bi bi-x">' + (data["msgs"].join("<br>")) + '</div>';

                // console.log(result);

                $("#result").html(msg);
                console.log(msg);
                console.log(result);
                const myDeleteModal = new bootstrap.Modal('#deleteModal');
                myDeleteModal.hide();
                $("#result").html(msg);
            }
        }
    })

}

// $("#deleteModalBtn").on('click', function(e){

//     const myDeleteModal2 = new bootstrap.Modal('#deleteModal');
//     myDeleteModal2.hide();

//     // alert("Запрос удаления отправлен на сервер");

// })



// нажатие кнопки удалить в модальном окне

$('#deleteModalBtn')
    .on('click', function(e) {

        const myDeleteModal = new bootstrap.Modal('#deleteModal');
        console.log(deleteModal);

        // // проверка на некорректные значения
        // var id = $('#deleteModal').find('#delete_id').val();
        // var name = $('#deleteModal').find('#delete_name').val();
        // var provider = $('#deleteModal').find('#delete_provider').val();
        // var count = $('#deleteModal').find('#delete_count').val();

        // var con0 = ((id == "")||(!id));
        // var con1 = (name == "");
        // var con2 = (provider == "");
        // var con3 = (count == "");

        // if (con0 || con1 || con2 || con3) {

        // } else {

        //     var products = [{
        //         "id": id,
        //         "name": name,
        //         "provider": provider,
        //         "count": count
        //     }];
        //     deleteRecord(products);
        // }
        // // const myDeleteModal = new bootstrap.Modal('#deleteModal');
        // // $('#deleteModal').hide();
        myDeleteModal.hide();
    })

// Сам запрос на удаление записи - работа с сервером
function deleteRecord2(products) {

    console.log(products);

    var jqxhr = $.ajax({

        url: '/api/products/delete',
        type: 'DELETE',
        data: JSON.stringify({ products }),
        dataType: "JSON",

        success: function(data) {

            if (!data["status"]) {

                var msg = '<div class="alert alert-danger"><i class="bi bi-x">' + (data["msgs"].join("<br>")) + '</div>';
                result = '<div class="alert alert-danger"><i class="bi bi-x">' + (data["msgs"].join("<br>")) + '</div>';
            }

            if (data["status"]) {

                var msg = '<div class="alert alert-success"><i class="bi bi-x-square"></i><i class="bi bi-x">' + (data["msgs"].join("<br>")) + '</div>';
                result = '<div class="alert alert-success"><i class="bi bi-x">' + (data["msgs"].join("<br>")) + '</div>';
            }

            const myModal = new bootstrap.Modal('#deleteModal');
            myModal.hide();

            $("#result").html(msg);
            console.log(msg);
            console.log(result);
            $('#result').html(result);
            fetch();
        },

        error: function(jqxhr, status, data) {

            console.log(data);
            console.log(jqxhr.responseText);
            var data = $.parseJSON(jqxhr.responseText);

            if (!data["status"]) {

                var msg = '<div class="alert alert-danger"><i class="bi bi-x">' + (data["msgs"].join("<br>")) + '</div>';
                result = '<div class="alert alert-danger"><i class="bi bi-x">' + (data["msgs"].join("<br>")) + '</div>';

                // console.log(result);

                $("#result").html(msg);
                console.log(msg);
                console.log(result);
                const myDeleteModal = new bootstrap.Modal('#deleteModal');
                myDeleteModal.hide();
                $("#result").html(msg);
            }
        }
    })

}