	var createModal = new bootstrap.Modal(document.getElementById('createModal'))
	
	$("#createModalBtn").on('click', function(e){
		create_record();
		fetch();
		createModal.hide();
	})
	
	var updateModal = new bootstrap.Modal(document.getElementById('updateModal'))
	
	$("#updateModalBtn").on('click', function(e){
		
		var id = $('#updateModal').find('#edit_id').val();
        var name = $('#updateModal').find('#edit_name').val();
        var provider = $('#updateModal').find('#edit_provider').val();
        var count = $('#updateModal').find('#edit_count').val();

        var products = [{
            "id": id,
            "name": name,
            "provider": provider,
            "count": count
        }];

        console.log(products);

        var con0 = ((id == "")||(!id));
        var con1 = (name == "");
        var con2 = (provider == "");
        var con3 = (count == "");

        if (con0 || con1 || con2 || con3) {

            console.log('Ошибка ввода');
            $("#result-update-modal").html('<div class="alert alert-danger result-modal">Ошибка ввода</div>');
			return(0);
        }

		update_record(products);
		updateModal.hide();
		fetch();
	})
	
	var deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'))
	
	$("#deleteModalBtn").on('click', function(e){
		
		// проверка на некорректные значения
        var id = $('#deleteModal').find('#delete_id').val();
        var name = $('#deleteModal').find('#delete_name').val();
        var provider = $('#deleteModal').find('#delete_provider').val();
        var count = $('#deleteModal').find('#delete_count').val();

        var con0 = ((id == "")||(!id));
        var con1 = (name == "");
        var con2 = (provider == "");
        var con3 = (count == "");
		
		var products = [{
			"id": id,
			"name": name,
			"provider": provider,
			"count": count
		}];
		
		console.log("products=", products);

		// При некоррктных значениях удаляемой записи - вывод в модальном окне предупреждения
		// и просто возврат к моадльному окну
        if (con0 || con1 || con2 || con3) {
			console.log('Ошибка ввода');
			$("#result-delete-modal").html('<div class="alert alert-warning">Ошибка ввода: некорректные значения</div>');
			return(0);
        }

        delete_record(products);
		deleteModal.hide();
		fetch();
	})
	
	// При закрытии модальных окон очищаем все поля и делаем запрос на получение всех записей
	$("#updateModal").on("hidden.bs.modal", function(e) {
		// $('#edit_name').val = "";
		// $('#edit_provider').val = "";
		// $('#edit_count').val = "";
		$('#result-update-modal').html("");
		fetch();
	})
	
	// При закрытии моадльных окон очищаем все поля и делаем запрос на получение всех записей
	$("#deleteModal").on("hidden.bs.modal", function(e) {
		// $('#delete_name').val = "";
		// $('#delete_provider').val = "";
		// $('#delete_count').val = "";
		$('#result-delete-modal').html("");
		fetch();
	})
	
	$('#fetchAllBtn').on('click', function(e){
		$('#result').html('<div class="alert alert-success"><i class="bi bi-x-square"></i>Обновление всех записей успешно выполнено</div>');
		// fetch();
	})


function fetch() {

    $.ajax({
        url: "/api/products/fetchall",
        type: "POST",
        success: function(data) {

            console.log(typeof(data));
            console.log(data);


            var box_content = document.querySelector("#box_content");
            box_content.innerHTML = "";
            var box_content1 = $("#box_content");

            for (let ob of data) {

                // $("#box_content").append("<div>qwerty</div>"); 
                $("#box_content").append('<div id="record_' + ob["id"] + '" namne="record_' + ob["id"] + '" class="row mt-1"></div>');
                // $('#record_'+ob["id"]).append('<div id="name_box_'+ob["id"]+'" namne="name_box_'+ob["id"]+'"><input type="text" id="name_'+ob["id"]+'" name="name_'+ob["id"]+'" value="'+ob["name"]+'"></div>');

                $('#record_' + ob["id"]).append('<div id="name_box_' + ob["id"] + '" namne="name_box_' + ob["id"] + '" class="col-md-auto"></div>');
                $('#record_' + ob["id"]).append('<div id="provider_box_' + ob["id"] + '" namne="provider_box_' + ob["id"] + '" class="col-md-auto"></div>');
                $('#record_' + ob["id"]).append('<div id="count_box_' + ob["id"] + '" namne="count_box_' + ob["id"] + '" class="col-md-auto"></div>');

                $('#record_' + ob["id"]).append('<div id="action_edit_box_' + ob["id"] + '" namne="action_edit_box_' + ob["id"] + '" class="col-md-auto"></div>');
                $('#record_' + ob["id"]).append('<div id="action_delete_box_' + ob["id"] + '" namne="action_delete_box_' + ob["id"] + '" class="col-md-auto"></div>');


                $('#name_box_' + ob["id"]).append('<input type="text" id="name_' + ob["id"] + '" name="name_' + ob["id"] + '" value="' + ob["name"] + '">');
                $('#provider_box_' + ob["id"]).append('<input type="text" id="provider_' + ob["id"] + '" name="provider_' + ob["id"] + '" value="' + ob["provider"] + '">');
                $('#count_box_' + ob["id"]).append('<input type="text" id="count_' + ob["id"] + '" name="count_' + ob["id"] + '" value="' + ob["count"] + '">');

                // $('#record_'+ob["id"]).append('<div id="provider_box_'+ob["id"]+'" namne="provider_box_'+ob["id"]+'" class="col-md-auto"><input type="text" id="provider_'+ob["id"]+'"  name="provider_'+ob["id"]+'" value="'+ob["provider"]+'"></div>');
                // $('#record_'+ob["id"]).append('<div id="count_box_'+ob["id"]+'" namne="count_box_'+ob["id"]+'" class="col-md-auto"><input type="text" id="count_'+ob["id"]+'"  name="count_'+ob["id"]+'" value="'+ob["count"]+'"></div>');
                // $('#record_'+ob["id"]).append('<div id="action_edit_box_'+ob["id"]+'" namne="action_edit_box_'+ob["id"]+'" class="col-md-auto"><button type="submit">Редактировать<button></div>');

                $('#action_edit_box_' + ob["id"]).append('<button type="submit" id="action_delete_' + ob["id"] + '" name="action_delete_' + ob["id"] + '" class="btn btn-success">Редактировать</button></div>');
                $('#action_delete_box_' + ob["id"]).append('<button type="submit" id="action_delete_' + ob["id"] + '" name="action_delete_' + ob["id"] + '" class="btn btn-danger">Удалить</button>');
                // $('#action_edit_box_' + ob["id"]).append('<button type="submit" id="action_delete_' + ob["id"] + '" name="action_delete_' + ob["id"] + '" class="btn btn-success"><i class="bi bi-pencil-square"></i></button></div>');
                // $('#action_delete_box_' + ob["id"]).append('<button type="submit" id="action_delete_' + ob["id"] + '" name="action_delete_' + ob["id"] + '" class="btn btn-danger"><i class="bi bi-trash3"></i></button>');

            }

        }
    });
}



function create_record(){
	
	    // Чтение значений полей из модального окна создания записи
    var products = [{

        "name": $("#name").val(),
        "provider": $("#provider").val(),
        "count": $("#count").val()
    }];
	
	var con1 = (products[0]["name"]=="");
	var con2 = (products[0]["provider"]=="");
	var con3 = (products[0]["count"]=="");
	
	if (con1 || con2 || con3){
		// alert("Ошибка ввода");
		var result = '<div class="alert alert-danger"><i class="bi bi-x">Ошибка ввода</div>';
		$("#result").html(result);
		return(0);
	}
	
	$.ajax({
		
		url: '/api/products/create',
        type: 'POST',
        data: JSON.stringify({ products }),
        dataType: "JSON",
		
		
		success: function(jqxhr, status, data){
			console.log('success', data);
			var response = data.responseJSON;
			console.log('response', response);
			console.log('success', response.msgs);
			// console.log('success', ($.parseJSON(jqxhr.responseJSON))["msgs"]);
			 var msg = '<div class="alert alert-danger"><i class="bi bi-x">' + (response.msgs.join("<br>")) + '</div>';
			result = '<div class="alert alert-danger"><i class="bi bi-x">' + (response.msgs.join("<br>")) + '</div>';
			$("#result_create").innerHTML = msg;
			$("#result").html('<div class="alert alert-success"><i class="bi bi-x-square"></i>'+(response.msgs.join("<br>"))+'</div>');
			console.log(result);
			// myModal.hide();
		},

		// complete: function(jqxhr, status, data){
			// var response = data.responseJSON;
			// console.log('completed', response);
			// var msg = '<div class="alert alert-danger"><i class="bi bi-x">' + (response.msgs.join("<br>")) + '</div>';
            // var result = '<div class="alert alert-danger"><i class="bi bi-x">' + (response.msgs.join("<br>")) + '</div>';
			// $("#result").innerHTML = msg;
			// console.log(result);
		// },

		error: function(jqxhr, status, data){
			var response = data.responseJSON;
			console.log('error', response);
			var msg = '<div class="alert alert-danger"><i class="bi bi-x">' + (response.msgs.join("<br>")) + '</div>';
			var result = '<div class="alert alert-danger"><i class="bi bi-x">' + (response.msgs.join("<br>")) + '</div>';
			$("#result").html(msg);
			console.log(result);
		}
	})
}

function update_record(products){
	$.ajax({
		// url: 'https://jsonplaceholder.typicode.com/posts1/1',
		// type: 'PUT',
		// data: JSON.stringify({
				// id: 1,
				// title: 'foo',
				// body: 'bar',
				// userId: 1,
		// }),
		// dataType: "JSON",
		
		url: '/api/products/update',
        type: 'PUT',
        data: JSON.stringify({products}),
        dataType: "JSON",
		
		
		success: function(jqxhr, status, data){
			// $("#updateModalBody").append("ХОРОШО");
			console.log('success', data);
			var response = data.responseJSON;
			console.log('response', response);
			console.log('success', response.msgs);
			// var updateModal = new bootstrap.Modal(document.getElementById('updateModal'));
			// updateModal.hide();

			$("#result").html('<div class="alert alert-success"><i class="bi bi-x-square"></i>'+response.msgs.join("<br>")+'</div>');
		},

		complete: function(data){
			
			// $("#updateModalBody").append("ЗАВЕРШЕНО");
			console.log('completed', data);
			// var updateModal = new bootstrap.Modal(document.getElementById('updateModal'));
			updateModal.hide();
		},

		error: function(jqxhr, status, data){
			
			// $("#updateModalBody").append("ОШИБКА");
			console.log('error', data);
			var response = data.responseJSON;
			console.log('response', response);
			console.log('error', response.msgs);
			// var updateModal = new bootstrap.Modal(document.getElementById('updateModal'));
			$("#result").html('<div class="alert alert-danger"><i class="bi bi-x-square"></i>'+response.msgs.join("<br>")+'</div>');
			updateModal.hide();
		}
	})
			updateModal.hide();
}

function delete_record(products){

	$.ajax({

        url: '/api/products/delete',
        type: 'DELETE',
        data: JSON.stringify({ products }),
        dataType: "JSON",

		success: function(jqxhr, status, data){

			// console.log('success', data);
			// $("#result").html('<div class="alert alert-success">'+data+'</div>');

			console.log('success', data);
			var response = data.responseJSON;
			console.log('response', response);
			console.log('success', response.msgs);

			$("#result").html('<div class="alert alert-success"><i class="bi bi-x-square"></i>'+response.msgs.join("<br>")+'</div>');
			deleteModal.hide();
		},

		completed: function(jqxhr, status, data){
			
			// console.log('completed', data);
			// $("#result").html('<div class="alert alert-danger">'+data+'</div>');
			deleteModal.hide();
		},

		error: function(jqxhr, status, data){

			// $("#updateModalBody").append("ОШИБКА");
			console.log('error', data);
			var response = data.responseJSON;
			console.log('response', response);
			console.log('error', response.msgs);
			// var updateModal = new bootstrap.Modal(document.getElementById('updateModal'));
			$("#result").html('<div class="alert alert-danger"><i class="bi bi-x-square"></i>'+response.msgs.join("<br>")+'</div>');
			deleteModal.hide();
		}
	})
	deleteModal.hide();
}

// https://reqres.in/api/users;

$(document).ready(function(e){

	console.log("test");
	fetch();
	// alert("test");
	

})


$('#box_content')
        
    .on('click', '.btn-danger', function(e) {

        // $(this).closest('.row').remove()

        var parent_id = this.parentNode; //.id;
        var el_id = e.target.id;
        var record_id = el_id.split("_")[2];
        console.log(parent_id);
        console.log(e.target.id);
        console.log(record_id);

        const row = $(this).closest('.row')

        console.log('name', row.find('input[name="name_' + record_id + '"]').val())
        console.log('provider', row.find('input[name="provider_' + record_id + '"]').val())
        console.log('count', row.find('input[name="count_' + record_id + '"]').val())

        console.log($('#deleteModal').find('#delete_id').val(record_id));
        console.log($('#deleteModal').find('#delete_name').val($("#name_" + record_id).val()));
        console.log($('#deleteModal').find('#delete_provider').val($("#provider_" + record_id).val()));
        console.log($('#deleteModal').find('#delete_count').val($("#count_" + record_id).val()));

        // const myDeleteModal = new bootstrap.Modal('#deleteModal')

        deleteModal.show();

    })

    .on('click', '.btn-success', function(e) {

        var parent_id = this.parentNode; //.id;
        var el_id = e.target.id;
        var record_id = el_id.split("_")[2];
        
        console.log(parent_id);
        console.log(parent_id.parentNode.id);
        console.log(e.target.id);
        console.log(record_id);

        const row = $(this).closest('.row')

        console.log('name', row.find('input[name="name_' + record_id + '"]').val())
        console.log('provider', row.find('input[name="provider_' + record_id + '"]').val())
        console.log('count', row.find('input[name="count_' + record_id + '"]').val())

        console.log($('#updateModal').find('#edit_id').val(record_id));
        console.log($('#updateModal').find('#edit_name').val($("#name_" + record_id).val()));
        console.log($('#updateModal').find('#edit_provider').val($("#provider_" + record_id).val()));
        console.log($('#updateModal').find('#edit_count').val($("#count_" + record_id).val()));

        // Отображение модального окна удаления
        // const updateModal = new bootstrap.Modal('#updateModal')
        updateModal.show();
		// $("#updateModalBtn").hide();
    })

// При клике на результат - очишаем поле с его значением
$('#result').on('click', function(e){
	$(this).html("");
});