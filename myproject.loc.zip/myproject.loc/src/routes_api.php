<?php

return [
    '~^articles/list$~' => [\MyProject\Controllers\Api\ArticlesApiController::class, 'list'],
    '~^articles/(\d+)$~' => [\MyProject\Controllers\Api\ArticlesApiController::class, 'view'],
    '~^articles/add$~' => [\MyProject\Controllers\Api\ArticlesApiController::class, 'add'],
    
    '~^products/fetch$~' => [\MyProject\Controllers\Api\ProductsApiController::class, 'list'],
    '~^products/fetchall$~' => [\MyProject\Controllers\Api\ProductsApiController::class, 'fetchAll', "POST"],
    '~^products/create$~' => [\MyProject\Controllers\Api\ProductsApiController::class, 'create',"POST"],
    '~^products/read$~' => [\MyProject\Controllers\Api\ProductsApiController::class, 'read',"GET"],
    '~^products/update$~' => [\MyProject\Controllers\Api\ProductsApiController::class, 'update',"PUT"],
    '~^products/delete$~' => [\MyProject\Controllers\Api\ProductsApiController::class, 'delete','DELETE'],
    // '~^products/all$~' => [\MyProject\Controllers\Api\ArticlesApiController::class, 'fetchAll'],
];