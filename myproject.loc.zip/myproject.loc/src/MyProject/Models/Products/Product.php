<?php

namespace MyProject\Models\Products;

use MyProject\Exceptions\InvalidArgumentException;
use MyProject\Models\ActiveRecordEntity;
use MyProject\Models\Users\User;

class Product extends ActiveRecordEntity
{
    /** @var string */
    protected $name;

    /** @var string */
    protected $provider;

    /** @var int */
    protected $count;

    /** @var string */
    // protected $createdAt;

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return string
     */
    public function getProvider(): string
    {
        return $this->provider;
    }

    /**
     * @return int
     */
    public function getCount(): int
    {
        return $this->count;
    }

    /**
     * @param string $name
     */
    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * @param string $provider
     */
    public function setProvider(string $provider): void
    {
        $this->provider = $provider;
    }

    /**
     * @param int $count
     */
    public function setCount(string $count): void
    {
        $this->count = $count;
    }


    public static function createFromArray(array $fields): Product
    {
        if (empty($fields['name'])) {
            throw new InvalidArgumentException('Не передано название');
        }

        if (empty($fields['provider'])) {
            throw new InvalidArgumentException('Не передано имя поставщика');
        }

        if (empty($fields['count'])) {
            throw new InvalidArgumentException('Не передано количество продукта');
        }

        $product = new Product();

        $product->setName($fields['name']);
        $product->setProvider($fields['provider']);
        $product->setCount($fields['count']);

        $product->save();

        return $product;
    }

    public function updateFromArray(array $fields): Product
    {
        if (empty($fields['name'])) {
            throw new InvalidArgumentException('Не передано название статьи');
        }

        if (empty($fields['provider'])) {
            throw new InvalidArgumentException('Не передано имя поставщика');
        }

        if (empty($fields['count'])) {
            throw new InvalidArgumentException('Не передано количество продукта');
        }

        $this->setName($fields['name']);
        $this->setProvider($fields['provider']);
        $this->setCount($fields['count']);

        $this->save();

        return $this;
    }

    protected static function getTableName(): string
    {
        return 'products';
    }
}