<?php

namespace MyProject\Controllers\Api;

use IntlChar;
use MyProject\Controllers\AbstractController;
use MyProject\Exceptions\NotFoundException;
// use MyProject\Models\Articles\Article;
use MyProject\Models\Products\Product;
use MyProject\Models\Users\User;

class ProductsApiController extends AbstractController
{
    public function view(int $articleId)
    {
        $article = Article::getById($articleId);

        if ($article === null) {
            throw new NotFoundException();
        }

        $this->view->displayJson([
            'articles' => [$article]
        ]);
    }

    public function add0()
    {
        $input = json_decode(
            file_get_contents('php://input'),
            true
        );
        var_dump($input);

        
    }

    public function add()
    {
        $input = $this->getInputData();
        $articleFromRequest = $input['articles'][0];
        
        $authorId = $articleFromRequest['author_id'];
        $author = User::getById($authorId);
        
        $article = Article::createFromArray($articleFromRequest, $author);
        $article->save();
        
        header('Location: /api/articles/' . $article->getId(), true, 302);
    }
    

    public function fetchAll()
    {

        
        $input = $this->getInputData();
        
        $articles = Product::findAll();

        $this->view->displayJson($articles, 200);
    }
    
    public function update()
    {
        $response   = [
            "status"    => true,
            "data"      => null,
            "msgs"      => [],
        ];

        $input = $this->getInputData();
        $FromRequest = $input['products'][0];
        
        if ((!isset($FromRequest["name"])||(strlen($FromRequest["name"])<1))){
            
            $response["msgs"][] = "Не корректное название продукта";
        }

        if ((!isset($FromRequest["provider"])||(strlen($FromRequest["provider"])<1))){
            
            $response["msgs"][] = "Не корректное название поставщика";
        }
        
        if ((!isset($FromRequest["count"])||(strlen($FromRequest["count"])<1))){
            $response["msgs"][] = "Не корректное количество продукта";
        }
        
        if (count($response["msgs"])>0){
            
            $response["status"] = false;
            $this->view->displayJson($response, 400);
            exit();
        }

        try {
            //code...
            $product    = Product::getById($FromRequest["id"]);
            $product->setName($FromRequest["name"]);
            $product->setProvider($FromRequest["provider"]);
            $product->setCount($FromRequest["count"]);
            $product->save();
            
        } catch (\Throwable $th) {
            //throw $th;
            $response["status"] = false;
            $response["msgs"][] = "Ошибка обновления записи.";
            $this->view->displayJson($response, 501);
            exit();
        }
        
        try {
            //code...
            $product = Product::getById(($FromRequest["id"]));
            $response["data"] = $product;
            
        } catch (\Throwable $th) {
            //throw $th;
            $response["status"] = false;
            $response["msgs"][] = "Ошибка чтения записи после обновления.";
            $this->view->displayJson($response, 501);
            exit();
            
        }
        
        $response["msgs"][] = "Обновление записи успешно выполнено."; 
        $this->view->displayJson($response, 200);
    }

    public function delete()
    {
        $response   = [
            "status"    => true,
            "data"      => null,
            "msgs"      => [],
        ];

        $input = $this->getInputData();
        $FromRequest = $input['products'][0];
 
        if (!isset($FromRequest["id"])){
            $response["msgs"][] = "Запись не обнаружена." ;
            $response["msgs"][] = "Ошибка запроса на удаление"; 
        }
        
        if (count($response["msgs"])>0){
            $response["status"] = false;
            $response["data"] = $FromRequest;
            $this->view->displayJson($response, 404);
            exit();
        }
        
        
        
        try {
            //code...
            $product = Product::getById(intval($FromRequest["id"]));
            $product->delete();
        } catch (\Throwable $th) {
            //throw $th;
            $response["msgs"][] = "Ошибка при удалении записи";
            $response["status"] = false;
            $response["data"]   = $FromRequest;
            $this->view->displayJson($response, 500);
            exit();
        }
        
        $response["data"]   = $FromRequest;
        $response["msgs"][] = "Запись успешно удалена";
        $this->view->displayJson($response, 200);
    }
    
    public function create()
    {
        $response   = [
            "status"    => true,
            "data"      => null,
            "msgs"      => [],
        ];

        $input          = $this->getInputData();
        // var_dump($input);
        // var_dump(json_encode($input));
        $FromRequest    = $input['products'][0];
 
               
        if ((!isset($FromRequest["name"])||(strlen($FromRequest["name"])<1))){
            $response["status"] = false;
            $response["msgs"][] = "Не корректное название продукта";
        }

        if ((!isset($FromRequest["provider"])||(strlen($FromRequest["provider"])<1))){
            $response["status"] = false;
            $response["msgs"][] = "Не корректное название поставщика";
        }

        if ((!isset($FromRequest["count"])||(strlen($FromRequest["count"])<1))){
            $response["status"] = false;
            $response["msgs"][] = "Не корректное количество продукта";
        }
        
        
        if (count($response["msgs"])>0){
            $response["status"] = false;
            $response["data"] = $FromRequest;
            $this->view->displayJson($response, 404);
            exit();
        }
        
        
        // $product = new Product();
        // $product->setName($FromRequest["name"]);
        // $product->setProvider($FromRequest["provider"]);
        // $product->setCount($FromRequest["count"]);
        // $product->save();
        
        $product = Product::createFromArray($FromRequest);

        if($product==null){
            $response["status"] = false;
            $response["data"]   = $FromRequest;
            $response["msgs"][] = "Ошибка при создании записи";
            
            $this->view->displayJson($response, 500);
            exit();
        }
        
        $response["data"]   = $product;
        $response["msgs"][] = "Запись успешно создана.";
        $this->view->displayJson($response, 200);


    }


    
    public function read()
    {
        
        $response   = [
            "status"    => true,
            "data"      => null,
            "msgs"      => [],
        ];

        $input          = $this->getInputData();
        // var_dump($input);
        $FromRequest    = $input['products'][0];
 
        $con1 = (!isset($FromRequest["id"]));
        $con2 = (strlen($FromRequest["id"])<1);
        $con3 = (!is_numeric($FromRequest["id"]));

        if ($con1 || $con2 ||$con3){

            $response["status"] = false;
            $response["msgs"][] = "Запись не найдена. Ошибка в запросе.";
            
            $response["status"] = false;
            $response["data"] = $FromRequest;
            $this->view->displayJson($response, 400);
            exit();
        }

        // $product = new Product();
        // $product->setName($FromRequest["name"]);
        // $product->setProvider($FromRequest["provider"]);
        // $product->setCount($FromRequest["count"]);
        // $product->save();

        
        try {
            //code...
            $product = Product::getById($FromRequest["id"]);
        } catch (\Throwable $th) {
            //throw $th;

            $response["status"] = false;
            $response["data"]   = $FromRequest;
            $response["msgs"][] = "Ошибка при чтении записи";

            $this->view->displayJson($response, 500);
            exit();
        }

        if($product==null){
            $response["status"] = false;
            $response["data"]   = $FromRequest;
            $response["msgs"][] = "Запись не найдена";

            $this->view->displayJson($response, 404);
            exit();
        }
        
        $response["data"]   = $product;
        $this->view->displayJson($response, 200);
       
    }
}