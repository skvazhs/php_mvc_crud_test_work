<?php

namespace MyProject\Exceptions;

class NotFoundException extends \Exception
{
}
