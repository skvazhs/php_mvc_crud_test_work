<?php

namespace MyProject\Exceptions;

class InvalidArgumentException extends \Exception
{
}
