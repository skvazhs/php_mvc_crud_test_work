<?php

namespace MyProject\Exceptions;

class UnauthorizedException extends \Exception
{
}
