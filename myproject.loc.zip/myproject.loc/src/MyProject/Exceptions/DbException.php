<?php

namespace MyProject\Exceptions;

class DbException extends \Exception
{
}
