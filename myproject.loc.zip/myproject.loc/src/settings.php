<?php

return [
    'db' => [
        'host' => 'localhost',
        'dbname' => 'my_project',
        'user' => 'root',
        'password' => 'root',
    ]
];
